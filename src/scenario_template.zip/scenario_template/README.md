![](img/Trailer.png)

# 「しんはんにんさがし」
## はじめに

本作は、「 株式会社アークライト  」及び「株式会社KADOKAWA」が権利を有する『クトゥルフ神話TRPG』の二次創作物です。

Call of Cthulhu is copyright ©1981, 2015, 2019 by Chaosium Inc. ;all rights reserved. Arranged by Arclight Inc.
Call of Cthulhu is a registered trademark of Chaosium Inc.
PUBLISHED BY KADOKAWA CORPORATION　「クトゥルフ神話TRPG」
### 推奨人数 
2~4人
### 推奨技能
目星、聞き耳、戦闘技能
### 準推奨
図書館、心理学、拳銃またはナイフ
### ロストについて
ロストあり、後遺症KPCのみ可能性あり
### 探索者条件
共通の知り合いのKPCが存在すること
### プレイ時間 
推定１～２時間（RP次第で伸びる）
### 備考
神話生物の自己解釈、地獄の可能性あり


